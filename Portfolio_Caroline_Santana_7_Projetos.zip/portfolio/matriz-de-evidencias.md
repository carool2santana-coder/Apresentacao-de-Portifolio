# Matriz de competências e evidências

Esta matriz distingue experiência relatada, material disponível e informação ainda pendente. A ausência de anexo não invalida um relato, mas limita o que um leitor consegue verificar diretamente.

| Projeto | Competência relacionada | Evidência disponível nesta publicação | Limite |
| --- | --- | --- | --- |
| Motoboys | Levantamento de necessidades; organização financeira | Descrição da reunião e da planilha entregue | Planilha original e avaliação não anexadas; sem métricas |
| WhatsApp Business | Organização de catálogo; melhoria de processo de atendimento | Relato detalhado da atuação e dos efeitos observados | Catálogo perdido após troca de número; sem medição formal |
| Floricultura | Escopo individual; colaboração; implementação web básica | Descrição da seção institucional desenvolvida | Código e capturas não anexados |
| Saúde mental no trabalho | Coleta de percepções; análise; documentação de propostas | Descrição do formulário e relatório | Originais não anexados; propostas não implantadas |
| Missão E-Lixo | Planejamento; comunicação; organização de informação digital | Site, apresentação e cartaz com QR Code | Ação com participantes e avaliação ainda pendentes |
| RB Pratas | Levantamento inicial; escopo; decisões de negócio | Briefing estruturado e proposta de regras a validar | Sistema e requisitos homologados ainda não entregues |
| M-Sol | Visão de produto; definição de público; descoberta | Conceito e perguntas para levantamento futuro | Sem operação, pesquisa ou parceria confirmada |

## Critérios desta versão

- Experiências anteriores foram descritas com base nos relatos da autora.
- Necessidades e fluxos foram organizados retrospectivamente para apresentação profissional.
- A documentação não transforma planos em resultados.
- Nenhuma melhoria percentual ou financeira foi estimada como se tivesse sido medida.
- Dados individuais de clientes, participantes e crianças não integram os cases.
- O apoio de IA à redação e à organização é explicitado no índice.

**Data da organização:** 06/10/2026.

[Voltar ao portfólio](README.md)

