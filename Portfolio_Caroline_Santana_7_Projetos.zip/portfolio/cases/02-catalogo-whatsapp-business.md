# 02 · Organização de catálogo e atendimento no WhatsApp Business

**Contexto:** experiência profissional no Mercadão de Carnes Pantanal, 2024.  
**Atuação:** organização de informações de produtos e apoio à divulgação.  
**Status:** melhoria implementada na época.

## Contexto e problema

O estabelecimento já utilizava WhatsApp Business, mas não tinha um catálogo organizado nem divulgação diária dos produtos. Consultas sobre preços e disponibilidade geravam ligações que também chegavam ao caixa.

Identifiquei uma oportunidade de facilitar a consulta dos clientes usando uma ferramenta que a loja já possuía.

## O que eu fiz

- Fotografei os produtos.
- Cadastrei nomes, fotos e preços, incluindo valores por quilo, no catálogo.
- Divulguei ofertas pelo canal digital.
- Propus e ajudei a organizar uma campanha com sorteio de uma air fryer associada a compras e acompanhamento do Instagram.

A parte financeira da campanha ficou sob responsabilidade do proprietário. Não desenvolvi um aplicativo próprio: organizei o uso do WhatsApp Business existente.

## Mudança no atendimento

| Antes | Depois da organização do catálogo |
| --- | --- |
| Informações obtidas principalmente por contato direto | Produtos e preços também disponíveis para consulta no catálogo |
| Parte das consultas chegava por telefone ao caixa | Parte dos clientes passou a consultar e pedir pelo WhatsApp |
| Atendimento dependente da pergunta individual | Informações padronizadas em nome, foto e preço |

O telefone continuou sendo utilizado, inclusive por clientes idosos. A melhoria ampliou as possibilidades de atendimento.

## Resultado observado

No meu relato, clientes de apartamentos passaram a consultar preços e produtos e a fazer pedidos pelo WhatsApp. Observei redução de parte das ligações recebidas no caixa.

Não houve medição formal do volume de pedidos, da redução de chamadas ou do faturamento. Portanto, não atribuo percentuais ou aumento comprovado de vendas a essa ação.

## Aprendizados para análise de negócios

A experiência mostra como organizar informações pode reduzir atritos de atendimento sem criar um sistema do zero. Também evidencia a importância de considerar perfis de clientes com diferentes hábitos de comunicação.

Posteriormente, a troca do número de telefone levou à perda do catálogo. Isso destaca a necessidade de planejar a continuidade e a manutenção das informações de um canal comercial.

## Evidências

Case baseado no meu relato profissional. O catálogo original não está disponível nesta publicação, e não há capturas ou métricas anexadas.

**Ferramentas:** WhatsApp Business e Instagram como canal associado à campanha.

[Voltar ao portfólio](../README.md)

