# 04 · Pesquisa e propostas de melhoria sobre saúde mental no trabalho

**Contexto:** iniciativa acadêmica em ambiente de trabalho, 2026.  
**Atuação:** coleta de percepções, análise e documentação de propostas.  
**Status:** diagnóstico e relatório realizados; propostas não implantadas.

## Contexto e problema

Busquei compreender percepções sobre saúde mental no ambiente de trabalho e organizar informações que pudessem fundamentar propostas de melhoria.

O recorte deste case é a análise de uma necessidade organizacional e sua documentação. A pesquisa não é apresentada como avaliação clínica nem como diagnóstico de saúde dos participantes.

## O que eu fiz

- Preparei um formulário anônimo, sem solicitar dados pessoais.
- Reuni respostas para compreender percepções dos participantes.
- Analisei as informações coletadas.
- Elaborei um relatório com propostas e o encaminhei ao RH.

As propostas não foram acolhidas para implantação. A coleta e a documentação constituem as entregas realizadas.

## Processo documentado

| Etapa | Finalidade |
| --- | --- |
| Definir o tema | Delimitar a necessidade a investigar |
| Elaborar o formulário | Criar um canal de escuta |
| Analisar respostas | Organizar percepções e identificar questões para discussão |
| Elaborar o relatório | Traduzir achados em propostas |
| Apresentar ao RH | Submeter as propostas à decisão da organização |

Esta sequência sintetiza retrospectivamente o trabalho relatado. Não foram recuperados o questionário completo, o tamanho da amostra ou a lista exata de recomendações.

## Resultado e limites

O resultado concreto foi a produção da pesquisa e do relatório. Não há evidência de implantação das propostas nem de melhoria de indicadores organizacionais decorrente do projeto.

Por isso, o case não afirma redução de afastamentos, melhoria comprovada do clima ou qualquer resultado clínico.

## Aprendizados para análise de negócios

A experiência reforça que produzir uma análise e obter aprovação para executar suas recomendações são etapas diferentes. O alinhamento com quem decide e a definição do que pode ser implementado são partes importantes do processo.

Também demonstra a importância de comunicar achados com cuidado e de separar informações coletadas das interpretações e propostas.

## Evidências e privacidade

A descrição foi reconstruída a partir do meu relato. O formulário, a base de respostas e o relatório original não foram anexados. A organização é mantida sem identificação nesta versão pública, e nenhuma resposta individual é reproduzida.

**Recursos utilizados:** formulário digital e relatório de análise.

[Voltar ao portfólio](../README.md)

