# 05 · Missão E-Lixo: informação e educação ambiental

**Contexto:** projeto acadêmico e comunitário, 2026.  
**Atuação:** idealização, planejamento, materiais educativos e guia digital.  
**Status em 06/10/2026:** materiais preparados e site publicado; aplicação com participantes ainda em adaptação.

## Problema e público

A proposta parte da necessidade de aproximar informações sobre descarte de resíduos eletrônicos da realidade das crianças e de suas famílias.

O público inicialmente definido foi de crianças de 7 a 11 anos, com uma atividade planejada de aproximadamente 40 minutos. A linguagem, a personagem e a dinâmica foram organizadas para esse público.

## O que eu desenvolvi

- Conceito e identidade da personagem educativa Teka.
- Apresentação ilustrada e roteiro.
- Dinâmica de classificação com três caixas e cartões de itens.
- Cartazes com QR Code e orientações de descarte.
- Guia digital no Google Sites com informações e pontos de coleta.
- Planejamento da observação e da documentação da ação.

Usei IA como apoio à representação visual da Teka e à organização dos materiais. A concepção, a escolha do público e a proposta de atividade partiram de mim.

## Necessidades e decisões de solução

| Necessidade | Solução preparada |
| --- | --- |
| Explicar o tema para crianças | Linguagem simples, exemplos e personagem |
| Incentivar participação | Perguntas e dinâmica de classificação |
| Oferecer consulta depois da atividade | Guia digital |
| Facilitar acesso ao guia | QR Code nos materiais |
| Documentar a experiência | Planejamento de observação e registros autorizados |

## Adaptação do projeto

O planejamento inicial dependia de uma instituição parceira. Com a indisponibilidade das escolas, passei a avaliar outros formatos, incluindo a adaptação da apresentação para vídeo no site e participação digital.

Essas alternativas ainda não são apresentadas como executadas. A adequação do formato à atividade acadêmica precisa ser confirmada antes de encerrar o projeto.

## Entregas e resultados

Os materiais educativos e o guia digital são entregas concretas. A aplicação com participantes, a avaliação de aprendizagem e os resultados da ação ainda não estão concluídos nesta versão.

Não há número de crianças atendidas, volume de resíduos recolhidos ou percentual de conscientização a informar.

## Evidências disponíveis

- [Guia digital da Missão E-Lixo](https://sites.google.com/view/missao-e-lixo).
- [Apresentação no repositório](../../Miss%C3%A3o%20E-Lixo%20.pptx).
- [Cartaz com QR Code](../../Cartaz_Missao_E_Lixo_A4_QR_.pdf).
- [Descrição principal do projeto](../../README.md).

## Aprendizados e continuidade

O case demonstra planejamento para um público específico, organização de conteúdo e integração entre materiais físicos e um recurso digital. A necessidade de mudar o formato evidencia a importância de mapear dependências externas.

A próxima etapa é realizar a ação no formato definido, registrar a participação de maneira autorizada e produzir a análise dos resultados.

**Ferramentas:** Google Sites, PowerPoint, QR Code e ChatGPT como apoio visual e de organização.

[Voltar ao portfólio](../README.md)

