# 01 · Controle financeiro para motoboys

**Contexto:** projeto acadêmico, 2026.  
**Atuação:** levantamento de necessidades e elaboração de planilha.  
**Status:** solução entregue; aprovação acadêmica relatada.

## Contexto e problema

A rotina de entregas envolve recebimentos, gastos durante o trabalho e despesas de manutenção. Olhar apenas para o dinheiro recebido não permite perceber quanto efetivamente sobra.

Conversei com meus irmãos, que atuam como motoboys, para entender essa rotina e identificar o gargalo. O projeto envolveu três pessoas e uma reunião de levantamento.

## O que eu fiz

- Ouvi os participantes e identifiquei a necessidade de organizar ganhos e despesas.
- Criei uma planilha em Excel para registrar entradas, gastos na rua e manutenção.
- Estruturei a visualização dos ganhos e gastos com referência semanal e mensal.
- Entreguei a solução no contexto do projeto acadêmico.

Minha atuação concentrou-se na compreensão do problema e na construção de uma ferramenta simples para a rotina dos usuários.

## Necessidades traduzidas em solução

Síntese retrospectiva do escopo relatado:

| Necessidade | Resposta da solução |
| --- | --- |
| Saber quanto entrou | Registro de entradas |
| Perceber os custos do trabalho | Registro de gastos na rua e manutenção |
| Avaliar quanto sobra | Organização do saldo entre entradas e saídas |
| Acompanhar períodos | Visão semanal e mensal |

O processo considerado foi registrar os movimentos, organizar despesas e consultar o saldo do período. Não há confirmação de integração bancária ou automação de importação.

## Entrega e resultado

A entrega foi uma planilha de controle financeiro. O projeto acadêmico foi aprovado, conforme meu relato.

Não foram registrados indicadores de economia, aumento de renda ou frequência de uso. A proposta de valor foi tornar as informações financeiras mais visíveis e organizadas.

## Competências e aprendizado

Este case demonstra levantamento de necessidades, compreensão de um processo cotidiano e escolha de uma solução proporcional ao problema. A conversa com os usuários permitiu transformar uma dificuldade prática em uma ferramenta concreta.

## Evidências

A descrição foi reconstruída a partir do meu relato. A planilha original, capturas de tela e o comprovante de avaliação não foram anexados a esta pasta. Dados financeiros dos participantes não integram esta publicação.

**Ferramenta:** Microsoft Excel.

[Voltar ao portfólio](../README.md)

