# 03 · Seção institucional de um site de floricultura

**Contexto:** projeto acadêmico em equipe, disciplina de Programação Web, 2023.  
**Atuação:** desenvolvimento da seção institucional.  
**Status:** participação acadêmica realizada.

## Contexto e objetivo

O grupo desenvolveu um site de floricultura com HTML, CSS e JavaScript. Minha responsabilidade foi a seção “Instituição”, destinada à apresentação da organização no site.

O desafio do meu recorte era transformar informações institucionais em conteúdo de uma página web e integrar essa contribuição ao trabalho do grupo.

## Minha contribuição

Trabalhei na seção institucional, dentro do escopo distribuído entre os integrantes. O desenvolvimento do projeto utilizou VS Code e tecnologias básicas da web.

A autoria do site completo foi coletiva. Este case não atribui a mim as demais páginas, um catálogo completo, checkout, backend ou integrações não confirmadas.

## Leitura do case pela perspectiva de análise

| Aspecto | Aplicação no meu recorte |
| --- | --- |
| Escopo | Responsabilidade delimitada à seção institucional |
| Conteúdo | Apresentação das informações sobre a instituição |
| Colaboração | Integração de uma parte ao projeto do grupo |
| Solução | Página/seção construída com tecnologias web |

Esta organização do escopo é retrospectiva. Não há um documento original de requisitos anexado.

## Entrega e resultado

Minha entrega relatada foi a seção institucional do site acadêmico. Não há, nos materiais reunidos para esta versão, confirmação de publicação em produção, nota, métricas de acesso ou testes de usabilidade.

## Aprendizados

A experiência contribuiu para compreender a relação entre conteúdo, estrutura de páginas e implementação. Também permitiu trabalhar com uma responsabilidade definida dentro de uma entrega coletiva.

Para minha formação em análise, o principal aprendizado é a importância de delimitar o que cabe a cada participante e compreender como as partes compõem a solução.

## Evidências

O código original, capturas de tela e endereço publicado não estão anexados. Este documento registra a experiência; não apresenta um site novo como se fosse o trabalho realizado em 2023.

**Tecnologias do projeto:** HTML, CSS e JavaScript.  
**Ambiente:** VS Code.

[Voltar ao portfólio](../README.md)

