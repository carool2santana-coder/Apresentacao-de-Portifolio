# Caroline de Santana | Portfólio de Análise de Sistemas e Negócios

Sou estudante de Análise e Desenvolvimento de Sistemas, com interesse em requisitos, processos, regras de negócio e documentação. Reúno aqui experiências acadêmicas, melhorias que realizei no trabalho e projetos em estruturação.

Meu foco é entender uma necessidade, organizar as informações e propor uma solução adequada às pessoas que vão utilizá-la.

[LinkedIn](https://www.linkedin.com/in/caroline-de-santana-747345272/) · [GitHub](https://github.com/carool2santana-coder)

## Cases principais

| Case | Contexto | Minha contribuição | Estágio |
| --- | --- | --- | --- |
| [01 · Controle financeiro para motoboys](cases/01-controle-financeiro-motoboys.md) | Projeto acadêmico, 2026 | Levantamento de necessidades e planilha Excel | Solução entregue; aprovação acadêmica relatada |
| [02 · Catálogo no WhatsApp Business](cases/02-catalogo-whatsapp-business.md) | Experiência profissional, 2024 | Organização do catálogo e melhoria do atendimento | Implementado na época |
| [03 · Site de floricultura](cases/03-site-floricultura.md) | Projeto acadêmico em equipe, 2023 | Seção institucional do site | Participação acadêmica realizada |
| [04 · Pesquisa de saúde mental no trabalho](cases/04-pesquisa-saude-mental.md) | Iniciativa acadêmica/profissional, 2026 | Formulário, análise e relatório com propostas | Diagnóstico realizado; propostas não implantadas |
| [05 · Missão E-Lixo](cases/05-missao-e-lixo.md) | Projeto acadêmico e comunitário, 2026 | Planejamento, materiais educativos e guia digital | Materiais e site preparados; ação em adaptação |

## Projetos em estruturação

Estes dois projetos ampliam o portfólio com visão de produto e definição de escopo. Ainda não representam sistemas entregues ou serviços em funcionamento.

| Projeto | Foco | Estágio |
| --- | --- | --- |
| [06 · RB Pratas](em-planejamento/06-rb-pratas.md) | Requisitos de uma loja virtual e administração de pedidos | Levantamento inicial e decisões pendentes |
| [07 · M-Sol](em-planejamento/07-m-sol.md) | Concepção de uma iniciativa de apoio a mães solo | Visão inicial; operação e plataforma não implantadas |

## Como ler esta documentação

Cada case apresenta contexto, problema, minha atuação, entregas, resultados conhecidos e aprendizados. As tabelas de necessidades e os fluxos foram organizados retrospectivamente para este portfólio, em 06/10/2026, a partir das experiências relatadas. Não significam que uma especificação formal tenha sido produzida ou aprovada na época.

Resultados qualitativos são identificados como relatos da autora. Não atribuo percentuais, ganhos financeiros ou indicadores sem medição. Nos projetos em planejamento, requisitos e critérios sugeridos ainda precisam de validação.

Os arquivos originais de todos os projetos não estão reunidos neste repositório. Cada case informa as evidências disponíveis e seus limites.

## Competências relacionadas

- Escuta e levantamento de necessidades.
- Organização de informações e identificação de gargalos.
- Análise de processos e definição de escopo.
- Comunicação com diferentes públicos e partes interessadas.
- Documentação de soluções e distinção entre entrega, resultado e expectativa.
- Uso de Excel, WhatsApp Business, Google Sites, formulários e apresentações.
- Experiência acadêmica básica com HTML, CSS, JavaScript e VS Code.

Consulte a [matriz de competências e evidências](matriz-de-evidencias.md).

## Autoria e apoio

Experiências e projetos de Caroline de Santana. A organização e a redação desta versão do portfólio contaram com apoio de IA, a partir dos relatos da autora e dos materiais disponíveis. Esse apoio não substitui a validação dos requisitos pelos envolvidos.

[Voltar à Missão E-Lixo](../README.md)

