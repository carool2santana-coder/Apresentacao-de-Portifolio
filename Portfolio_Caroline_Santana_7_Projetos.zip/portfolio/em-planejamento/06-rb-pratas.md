# 06 · RB Pratas: levantamento inicial para loja virtual

**Natureza:** projeto para um negócio real, em estruturação.  
**Atuação nesta etapa:** compreensão da operação e definição inicial de escopo.  
**Status em 06/10/2026:** requisitos iniciais organizados; implementação e operação não comprovadas.

## Contexto e objetivo

A RB Pratas já possui loja física e vende por Instagram e WhatsApp. O objetivo do projeto é ampliar as possibilidades de venda com uma loja virtual e permitir que o proprietário administre produtos e pedidos.

A identidade prevista utiliza o nome RB Pratas e predominância de preto. O estoque atual é controlado manualmente.

## Escopo inicial levantado

| ID | Necessidade registrada | Estágio |
| --- | --- | --- |
| RF01 | Exibir anéis, brincos, correntes e pulseiras, com variações | Levantamento inicial |
| RF02 | Permitir cadastro, edição, ativação e desativação de produtos no painel | Levantamento inicial |
| RF03 | Oferecer checkout e alternativa de finalizar pelo WhatsApp | Forma de pagamento a definir |
| RF04 | Gerenciar pedidos no painel | Fluxo detalhado a validar |
| RF05 | Atualizar status: recebido, em separação, saiu e entregue | Fluxo inicial |
| RF06 | Considerar entrega local com taxa por endereço, a partir do Cambuci, SP | Cálculo da taxa a definir |

Os identificadores foram criados para organizar este documento. Não representam requisitos homologados pelo cliente.

## Propostas de regras para validação

- Produto desativado deve deixar de estar disponível para novas compras, preservando o histórico dos pedidos.
- O cliente deve conhecer a taxa e o total antes de confirmar o pedido.
- O fluxo pelo WhatsApp precisa definir como e quando o pedido passa a ser registrado no painel.
- O controle de variações e estoque precisa impedir promessas de disponibilidade sem confirmação.

Estas regras são sugestões de análise para a próxima etapa, ainda não funcionalidades entregues.

## Decisões pendentes

| Decisão | Por que importa |
| --- | --- |
| Pagamento e confirmação | Define quando o pedido pode seguir para separação |
| Controle e reserva de estoque | Evita divergência entre vendas físicas e digitais |
| Raio e cálculo de entrega | Determina elegibilidade e custo |
| Plataforma e hospedagem | Influencia custos e manutenção |
| Fotos e dados dos produtos | Viabiliza o catálogo inicial |
| Orçamento e responsabilidades | Define implantação e continuidade |

## Entrega desta etapa

A contribuição documentada é a organização das necessidades e das decisões que precisam ser tomadas antes da construção. Não há afirmação de loja publicada, painel implementado ou vendas geradas.

## Aprendizado e próximos passos

O projeto exercita levantamento com o responsável pelo negócio, definição de escopo e identificação de dependências. A próxima etapa é validar requisitos, regras, custos e prioridades com o cliente.

**Evidências:** briefing relatado e organizado neste documento; sem sistema ou protótipo anexado.

[Voltar ao portfólio](../README.md)

