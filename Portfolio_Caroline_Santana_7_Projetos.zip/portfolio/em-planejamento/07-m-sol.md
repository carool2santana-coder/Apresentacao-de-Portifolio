# 07 · M-Sol: concepção de iniciativa de apoio a mães solo

**Natureza:** ideia de projeto social em estruturação.  
**Atuação nesta etapa:** visão, público e identidade inicial.  
**Status em 06/10/2026:** concepção; sem operação, instituição formal ou plataforma implantada comprovadas.

## Problema e visão

A proposta é construir uma rede de apoio que amplie autonomia e oportunidades para mães solo.

A visão de longo prazo contempla acolhimento, apoio escolar e cuidados com crianças, transporte e parcerias com universidades. Esses elementos são intenções de projeto, sem indicação de serviços já disponíveis.

## Definições iniciais

| Elemento | Direção estabelecida |
| --- | --- |
| Público | Mães solo |
| Propósito | Apoio, autonomia e oportunidades |
| Presença digital | Site como base de informação e redes sociais para comunidade |
| Identidade | Bordô, terracota, dourado e creme |
| Mensagem | “Ninguém deveria nadar sozinha.” |
| Comunicação | Dignidade e autonomia, sem estética de vitimização |

O nome “Fundação M-Sol” apareceu na concepção. Nesta documentação, M-Sol é tratado como nome de projeto, sem afirmar constituição jurídica.

## Recorte de análise proposto

Antes de definir funcionalidades, será necessário ouvir potenciais participantes e parceiros, compreender suas necessidades prioritárias e delimitar um serviço inicial viável.

| Pergunta de descoberta | Decisão que ajuda a tomar |
| --- | --- |
| Qual necessidade aparece com maior frequência? | Prioridade do primeiro serviço |
| Que apoio já existe na comunidade? | Possíveis parcerias e complementaridade |
| Quem poderá executar e manter a iniciativa? | Capacidade operacional |
| Quais informações precisam ser coletadas? | Escopo e cuidados com os dados |
| Como acompanhar o atendimento? | Forma de avaliar a iniciativa |

São perguntas para orientar o futuro levantamento, não pesquisa já realizada.

## Entrega desta etapa e limites

Foram definidos a visão inicial, o público e a direção de identidade. Não há rede de parceiros confirmada, número de beneficiárias, captação de recursos ou plataforma em funcionamento a apresentar.

## Competências em desenvolvimento

A proposta permite exercitar descoberta de necessidades, definição de público, priorização e distinção entre visão de longo prazo e primeira entrega possível.

A próxima etapa é validar o problema com o público e delimitar o escopo antes de construir o site ou anunciar serviços.

**Evidências:** conceito relatado e organizado neste documento; sem pesquisa de campo ou operação comprovada anexadas.

[Voltar ao portfólio](../README.md)

